#include "TriangleRefiner.hpp"

namespace GeDiM
{
    TriangleRefiner::TriangleRefiner() { meshPointer = NULL;}
	TriangleRefiner::~TriangleRefiner() { }
	void TriangleRefiner::SetMesh( GenericMesh& mesh ) {meshPointer = &mesh; }
    void TriangleRefiner::AddCellToRefine( const unsigned int& value )
    {
        //provo a lavorare con gli int; tratto CellstoCut come vector

        CellsToCut[value]=1;

        TriangleCell* cellaAttuale=(TriangleCell*)meshPointer->Cell(value);
        cellaAttuale->ruotafinoaquandononciloazzikka();

        // Se la cella che ho in input è gia stata doomed to be cut non c'è più nulla da fare
        if (cellaAttuale->HasProperty("CellaDaRaffinare"))
            return;

        // Altrimenti la setto da tagliare

        cellaAttuale->AddProperty("CellaDaRaffinare",(void*)true); //Vediamo se poi è utile

        // E mi registro qual'è il lato più lungo

        GenericEdge* longestEdge = (GenericEdge*)cellaAttuale->LongestEdgePtr();

        cellaAttuale->AddProperty("LongestEdge",(void*)longestEdge); //Vediamo se poi è utile(se è sempre il primo)

        // Poi registro sul lato più lungo il fatto che sia da tagliare
        // Poi ricorro sul vicino
        // Mi chiedo se esite il vicino destro e se non sono io
        if ((longestEdge->RightCell() != NULL) and (longestEdge->RightCell() != cellaAttuale))
            AddCellToRefine(longestEdge->RightCell()->Id());

        else if ((longestEdge->LeftCell() != NULL) and (longestEdge->LeftCell() != cellaAttuale))
            AddCellToRefine(longestEdge->LeftCell()->Id());

        return;
    }
    Output::ExitCodes TriangleRefiner::RefineMesh()
    {
    	for(unsigned int i=0; i<CellsToCut.size(); i++){

    	    if(CellsToCut[i]!=0){

            GenericCell* cellaAttuale = meshPointer->Cell(i);
            GenericEdge* latolungo = meshPointer->Edge(cellaAttuale->Edge(0)->Id());

            //->GetProperty("LongestEdge");Una volta ruotato è sempre in posizione 0
            cout << "Raffino la cella numero: " << cellaAttuale->Id() << endl;

            const GenericPoint*A=latolungo->Point(0);
            const GenericPoint*B=latolungo->Point(1);
            const GenericPoint* D = cellaAttuale->Point(2);
            GenericPoint* PM= meshPointer->CreatePoint();

            PM->SetCoordinates(0.5*(A->Coordinates())+ 0.5*(B->Coordinates()));
          /*
          EVITIAMO L'ACCESSO DUE VOLTE NEGLI STESSI PUNTI

            Vector3d puntomedio = {
                (latolungo->Point(0)->X()+latolungo->Point(1)->X())/2.0,
                (latolungo->Point(0)->Y()+latolungo->Point(1)->Y())/2.0,
                0
            }; */

            meshPointer->CutEdgeWithPoints(latolungo->Id(),PM->Coordinates());


            GenericEdge* L1=(GenericEdge*)latolungo->Child(0);

            //const GenericPoint* C = L1->Point(1);---PUNTO MEDIO PM

            GenericEdge* latoNuovo= meshPointer->CreateEdge();
            meshPointer->AddEdge(latoNuovo);
            latoNuovo->AddPoint(PM);
            latoNuovo->AddPoint(D);

            latoNuovo->AllocateCells(2);

            //Crea la prima cella(DESTRA cd)
            //Crea la prima cella(DESTRA cd)
            /*GenericCell* Cd = meshPointer->CreateCell();
            meshPointer->AddCell(Cd);
            Cd->AddEdge(L1->Id());
            Cd->AddEdge(latoNuovo->Id());
            Cd->AddEdge(cellaAttuale->Edge(2)->Id());
            */
            list<unsigned int> listalati = {L1->Id(),latoNuovo->Id(),cellaAttuale->Edge(2)->Id()};
            list<unsigned int> listapunti = {,C->Id(),D->Id()};
            meshPointer->CreateCellChild2D(*Pippo, *cellaAttuale,listalati,listapunti,false);



            cout << CellsToCut.size() << endl;

            //Crea la seconda cella
            GenericEdge* L2 =(GenericEdge*)latolungo->Child(1);
            GenericCell* Pippo2 = meshPointer->CreateCell();
            meshPointer->AddCell(Pippo2);
            list<unsigned int> listalati2 = {L2->Id(),cellaAttuale->Edge(2)->Id(),latoNuovo->Id()};
            list<unsigned int> listapunti2 = {PM->Id(),B->Id(),D->Id()};
            meshPointer->CreateCellChild2D(*Pippo2, *cellaAttuale,listalati2,listapunti2,false);

            //controlla se bisogna tagliare altri lati nel figlio 1
            if(Pippo->Edge(2)->HasProperty("LatoDaTagliare")){
                     cout << "Rimando la cella numero: " << Pippo->Id() << endl;
                     cout << "a destra la numero: " << Pippo->Edge(2)->RightCell()->Id() << endl;
                     cout << "a sinistra la numero: " << Pippo->Edge(2)->LeftCell()->Id() << endl;

                    AddCellToRefine(Pippo->Id());
            }
            //controlla se bisogna tagliare altri lati nel figlio 2
            if(Pippo2->Edge(2)->HasProperty("LatoDaTagliare")){
                     cout << "Rimando la cella numero: " << Pippo2->Id() << endl;
                     cout << "a destra la numero: " << Pippo2->Edge(2)->RightCell()->Id() << endl;
                     cout << "a sinistra la numero: " << Pippo2->Edge(2)->LeftCell()->Id() << endl;
                    AddCellToRefine(Pippo2->Id());
                }


            latolungo->SetState(false);
    		cellaAttuale->SetState(false);
    		CellsToCut.erase(cellaAttuale);
    	}
    	}


    	return Output::Success;
    }
}
