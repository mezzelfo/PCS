#include "TriangleRefiner.hpp"

namespace GeDiM
{
    TriangleRefiner::TriangleRefiner() { meshPointer = NULL;}
	TriangleRefiner::~TriangleRefiner() { }
	void TriangleRefiner::SetMesh( GenericMesh& mesh ) {meshPointer = &mesh; }
    void TriangleRefiner::AddCellToRefine( const unsigned int& value )
    {
        TriangleCell* cellaAttuale = (TriangleCell*)meshPointer->Cell(value);
        cellaAttuale->ruotafinoaquandononciloazzikka();
        // Se la cella che ho in input è gia stata doomed to be cut non c'è più nulla da fare
        if (cellaAttuale->HasProperty("CellaDaRaffinare"))
            return;
        // Altrimenti la setto da tagliare
        CellsToCut.insert(cellaAttuale);
        cellaAttuale->AddProperty("CellaDaRaffinare",(void*)true);
        // E mi registro qual'è il lato più lungo
        GenericEdge* longestEdge = (GenericEdge*)cellaAttuale->LongestEdgePtr();
        cellaAttuale->AddProperty("LongestEdge",(void*)longestEdge);
        // Poi registro sul lato più lungo il fatto che sia da tagliare
        longestEdge->AddProperty("LatoDaTagliare",(void*)true);
        // Poi ricorro sul vicino
        // Mi chiedo se esite il vicino destro e se non sono io
        if ((longestEdge->RightCell() != NULL) and (longestEdge->RightCell() != cellaAttuale))
            AddCellToRefine(longestEdge->RightCell()->Id());
        else if ((longestEdge->LeftCell() != NULL) and (longestEdge->LeftCell() != cellaAttuale))
            AddCellToRefine(longestEdge->LeftCell()->Id());

        return;
    }
    Output::ExitCodes TriangleRefiner::RefineMesh()
    {
    	while(not CellsToCut.empty())
    	{
            GenericCell* cellaAttuale = *CellsToCut.begin();
            GenericEdge* latolungo = (GenericEdge*)cellaAttuale->GetProperty("LongestEdge");

            Vector3d puntomedio = {
                (latolungo->Point(0)->X()+latolungo->Point(1)->X())/2.0,
                (latolungo->Point(0)->Y()+latolungo->Point(1)->Y())/2.0,
                0
            };

            meshPointer->CutEdgeWithPoints(latolungo->Id(),vector<Vector3d>(1,puntomedio));

            GenericPoint* A = (GenericPoint*)latolungo->Point(0);
            GenericPoint* B = (GenericPoint*)latolungo->Point(1);


            GenericEdge* L1=(GenericEdge*)latolungo->Child(0);
            GenericEdge* L2 =(GenericEdge*)latolungo->Child(1);

            GenericPoint* C = (GenericPoint*)L1->Point(1);

            GenericEdge * latoNuovo= meshPointer->CreateEdge();
            meshPointer->AddEdge(latoNuovo);

            GenericPoint* D = (GenericPoint*)cellaAttuale->Point(2);

            latoNuovo->AddPoint(C);
            latoNuovo->AddPoint(D);

            GenericCell* Pippo = meshPointer->CreateCell();
            meshPointer->AddCell(Pippo);

            GenericCell alksdjaslk = *cellaAttuale;

            list<unsigned int> listalati = {L1->Id(),latoNuovo->Id(),cellaAttuale->Edge(1)->Id()};
            list<unsigned int> listapunti = {A->Id(),C->Id(),D->Id()};
            meshPointer->CreateCellChild2D(*Pippo, *cellaAttuale,listalati,listapunti);
            latolungo->SetState(false);
    		cellaAttuale->SetState(false);
    		CellsToCut.erase(cellaAttuale);
    	}


    	return Output::Success;
    }
}
